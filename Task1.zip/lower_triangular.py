def lower_triangular(n):
    for i in range(1, n + 1):
        print("* " * i)


n = 7
print("Lower Triangular:")
lower_triangular(n)
