def upper_triangular(n):
    for i in range(n, 0, -1):
        print("  " * (n - i) + "* " * i)


n = 7
print("\nUpper Triangular:")
upper_triangular(n)
